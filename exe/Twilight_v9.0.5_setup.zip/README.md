.............................................   TWILIGHT   (RC @Dec 10, 2018) .........................................

# A Poweful, Feature packed and Customisable Media Player

# Usage

1. Extract Twilight setup zip and install software
2. Head to search bar or installation directory and run "Twilight.exe"

# Update

1. Download update file (.rcup) from Author
2. run Update.exe or head to settings -> Update (in Twilight) and specify the location of Update file

# Registry Fix

1. To fix registry problems, head to installation directory and run REG.exe
2. It will reset all registry setting for the program...

# Features

1. Supports almost every VIDEO, AUDIO, and SUBTITLE codec out there
2. Scan Folder for media
3. Network Stream (supports YouTube, FTP, SMB, HHTP)

4. Playlists with Password Protection (save, load, organise, search)
5. Play videos and music in same playlist

6. Live Preview window when seeking (sliding across media)
7. Mini Controller for multi tasking
8. Mouse and Trackpad gestures for playback control

9. external Subtitles with Auto Scan
10. Resume Playback (play again from where you left of, save and load recent media)
11. Custom Aspect Ratio, Screenshots and video tools

12. Customise Everything (Keyboard Bindings, Gestures, Playback Options etc)
13. Supports Parallel Run (Multiple Instances at once)
14. Updates and Bug fixes (fully Modular)

# Support

E-mail: com.production.rc@gmail.com
